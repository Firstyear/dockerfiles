type flag =
  CError | CWarning | CSilent
