#define null(X) 0

extern const char *null_string;
extern int ai_protocol_any;

typedef const char *string;
typedef struct addrinfo addrinfo_t;
