open FStar_Buffer

let exit_success = 0
let exit_failure = 255

let string_of_literal s = s
let print_string = print_string
