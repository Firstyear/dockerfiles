/* Use only this module when debugging the Wasm transformations and compiling
 * with: -wasm -d force-c -drop C,WasmSupport -add-include '"wasm-stubs.h"' */
#define WasmSupport_check_buffer_size(X)
